"""This module defines the Rectangle class."""

__author__ = ""
__version__ = ""
