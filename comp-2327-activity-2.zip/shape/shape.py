"""This module defines the Shape class."""

__author__ = ""
__version__ = ""
