"""This module defines the Triangle class."""

__author__ = ""
__version__ = ""