# Intermediate Software Development Activity 2

This activity will help to reinforce learning of the Module 2 concepts of:

- Abstraction
- Inheritance
- Polymorphism
- Package Initialization

## Author

[Your name]

## Additional Information

[ Use this space to include additional information that may help in your learning. ]
